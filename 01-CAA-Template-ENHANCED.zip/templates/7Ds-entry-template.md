# 7Ds Entry Template

- Context:
- Goal:
- Inputs:
- Outputs:
- Owner:
