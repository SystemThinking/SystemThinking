# Principle Template

**Title:** 

**Description:** 

**Rationale:** 
