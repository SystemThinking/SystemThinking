# img

> This is a placeholder for `assets/img` content.
